import type { TSignalingMessage } from "./TSignalingMessage";

export function addIceCandidateEL(pc: RTCPeerConnection, msg: TSignalingMessage) {
    if (msg && false === 'candidate' in msg) {
        return
    }
    if (msg === null) {
        alert('Null Message received in addIceCandidateEL');
    }
    console.trace('Adding ICE Candidate', msg);
    pc.addIceCandidate(msg);
}