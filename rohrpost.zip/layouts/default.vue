<template>
<v-layout class="rounded rounded-md border">
    <v-app-bar title="Application bar"></v-app-bar>
    <v-main class="d-flex align-stretch justify-stretch">
    <slot></slot>
    </v-main>
  </v-layout>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>