<template>
  <v-app>
    <NuxtLayout>
      <NuxtPage>
      </NuxtPage>
    </NuxtLayout>
  </v-app>
</template>

<style>
  html {
    overflow-y: hidden;
  }
</style>