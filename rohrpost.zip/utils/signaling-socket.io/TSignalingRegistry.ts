export interface TSignalingRegistry {
    role: 'active' | 'passive';
    address: string;
}